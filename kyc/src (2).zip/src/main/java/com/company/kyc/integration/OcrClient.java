// package com.company.kyc.integration;

// import com.company.kyc.dto.OcrCombinedResponseDto;
// import com.fasterxml.jackson.databind.JsonNode;
// import com.fasterxml.jackson.databind.ObjectMapper;
// import lombok.RequiredArgsConstructor;
// import lombok.extern.slf4j.Slf4j;
// import org.springframework.core.io.ByteArrayResource;
// import org.springframework.http.*;
// import org.springframework.stereotype.Component;
// import org.springframework.util.LinkedMultiValueMap;
// import org.springframework.util.MultiValueMap;
// import org.springframework.web.client.RestTemplate;
// import org.springframework.web.multipart.MultipartFile;

// @Component
// @RequiredArgsConstructor
// @Slf4j
// public class OcrClient {

//     private final RestTemplate restTemplate;
//     private final ObjectMapper objectMapper;

//     private static final String OCR_BASE_URL = "http://192.168.0.200:8000/ocr/process";

//     /**
//      * Call consolidated OCR endpoint with PAN, Aadhaar and statement files.
//      */
//     public OcrCombinedResponseDto callOcrApi(MultipartFile panFile, MultipartFile aadhaarFile,
//             MultipartFile statementFile) {
//         long startTime = System.currentTimeMillis();

//         try {
//             log.debug("[OCR] Preparing multi-document OCR request to: {}", OCR_BASE_URL);
//             log.debug("[OCR] PAN File: {} size: {}", panFile.getOriginalFilename(), panFile.getSize());
//             log.debug("[OCR] Aadhaar File: {} size: {}", aadhaarFile.getOriginalFilename(), aadhaarFile.getSize());
//             log.debug("[OCR] Statement File: {} size: {}", statementFile.getOriginalFilename(),
//                     statementFile.getSize());

//             HttpHeaders headers = new HttpHeaders();
//             headers.setContentType(MediaType.MULTIPART_FORM_DATA);

//             MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
//             body.add("pan", toResource(panFile));
//             body.add("aadhaar", toResource(aadhaarFile));
//             body.add("bank", toResource(statementFile));

//             HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);

//             ResponseEntity<String> response = restTemplate.postForEntity(OCR_BASE_URL, requestEntity, String.class);
//             long duration = System.currentTimeMillis() - startTime;

//             if (response.getStatusCode() != HttpStatus.OK) {
//                 log.error("[OCR] API returned non-200 status: {}", response.getStatusCode());
//                 throw new RuntimeException("OCR API returned status: " + response.getStatusCode());
//             }

//             log.debug("[OCR] OCR response ({}ms): {}", duration, response.getBody());
//             OcrCombinedResponseDto combined = parseCombinedResponse(response.getBody());

//             log.info("[OCR] Combined response parsed: PAN={}, Aadhaar={}, Statement={}", combined.getPan(),
//                     combined.getAadhaar(), combined.getStatement());

//             return combined;
//         } catch (Exception e) {
//             long duration = System.currentTimeMillis() - startTime;
//             log.error("[OCR] Error in consolidated OCR invocation ({}ms): {}", duration, e.getMessage());
//             throw new RuntimeException("Error calling OCR service: " + e.getMessage(), e);
//         }
//     }

//     private ByteArrayResource toResource(MultipartFile file) {
//         try {
//             return new ByteArrayResource(file.getBytes()) {
//                 @Override
//                 public String getFilename() {
//                     return file.getOriginalFilename();
//                 }
//             };
//         } catch (Exception e) {
//             throw new RuntimeException("Failed to read multipart file " + file.getOriginalFilename(), e);
//         }
//     }

//     private OcrCombinedResponseDto parseCombinedResponse(String responseBody) throws Exception {
//         JsonNode root = objectMapper.readTree(responseBody);
//         OcrCombinedResponseDto combined = new OcrCombinedResponseDto();

//         if (root.has("pan")) {
//             combined.setPan(objectMapper.treeToValue(root.get("pan"), OcrCombinedResponseDto.PanData.class));
//         }
//         if (root.has("aadhaar")) {
//             combined.setAadhaar(
//                     objectMapper.treeToValue(root.get("aadhaar"), OcrCombinedResponseDto.AadhaarData.class));
//         }
//         if (root.has("statement")) {
//             combined.setStatement(
//                     objectMapper.treeToValue(root.get("statement"), OcrCombinedResponseDto.StatementData.class));
//         }

//         return combined;
//     }
// }

package com.company.kyc.integration;

import com.company.kyc.dto.OcrCombinedResponseDto;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

@Component
@RequiredArgsConstructor
@Slf4j
public class OcrClient {

    private final RestTemplate restTemplate;
    private final ObjectMapper objectMapper;

    private static final String OCR_BASE_URL = "http://192.168.0.200:8000/ocr/process";

    /**
     * Call consolidated OCR endpoint with PAN, Aadhaar and statement files.
     */
    public OcrCombinedResponseDto callOcrApi(
            MultipartFile panFile,
            MultipartFile aadhaarFile,
            MultipartFile statementFile) {

        long startTime = System.currentTimeMillis();

        try {
            log.info("[OCR] Calling OCR Process API");

            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.MULTIPART_FORM_DATA);

            MultiValueMap<String, Object> body = new LinkedMultiValueMap<>();
            body.add("pan", toResource(panFile));
            body.add("aadhaar", toResource(aadhaarFile));
            body.add("statement", toResource(statementFile));
            body.add("provider", "auto");

            HttpEntity<MultiValueMap<String, Object>> requestEntity = new HttpEntity<>(body, headers);

            ResponseEntity<String> response = restTemplate.postForEntity(OCR_BASE_URL, requestEntity, String.class);

            long duration = System.currentTimeMillis() - startTime;

            if (response.getStatusCode() != HttpStatus.OK) {
                log.error("[OCR] API returned non-200 status: {}", response.getStatusCode());
                throw new RuntimeException("OCR API returned status: " + response.getStatusCode());
            }

            log.info("[OCR] OCR response received in {} ms", duration);
            log.debug("[OCR] Response body: {}", response.getBody());

            return parseCombinedResponse(response.getBody());

        } catch (Exception e) {
            long duration = System.currentTimeMillis() - startTime;
            log.error("[OCR] Error calling OCR service ({} ms): {}", duration, e.getMessage());
            throw new RuntimeException("Error calling OCR service", e);
        }
    }

    private ByteArrayResource toResource(MultipartFile file) {
        try {
            return new ByteArrayResource(file.getBytes()) {
                @Override
                public String getFilename() {
                    return file.getOriginalFilename();
                }
            };
        } catch (Exception e) {
            throw new RuntimeException("Failed to read multipart file " + file.getOriginalFilename(), e);
        }
    }

    private OcrCombinedResponseDto parseCombinedResponse(String responseBody) throws Exception {
        JsonNode root = objectMapper.readTree(responseBody);
        OcrCombinedResponseDto combined = new OcrCombinedResponseDto();

        if (root.has("pan")) {
            combined.setPan(objectMapper.treeToValue(
                    root.get("pan"), OcrCombinedResponseDto.PanData.class));
        }

        if (root.has("aadhaar")) {
            combined.setAadhaar(objectMapper.treeToValue(
                    root.get("aadhaar"), OcrCombinedResponseDto.AadhaarData.class));
        }

        if (root.has("statement")) {
            combined.setStatement(objectMapper.treeToValue(
                    root.get("statement"), OcrCombinedResponseDto.StatementData.class));
        }

        return combined;
    }
}