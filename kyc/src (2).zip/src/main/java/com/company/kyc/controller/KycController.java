package com.company.kyc.controller;

import com.company.kyc.dto.KycProcessResponseDto;
import com.company.kyc.dto.KycResultResponseDto;
import com.company.kyc.service.KycService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/kyc")
@RequiredArgsConstructor
public class KycController {

    private final KycService kycService;

    // API 1 — Upload & Process KYC (PAN + Aadhaar + Statement)
    @PostMapping("/process")
    public ResponseEntity<KycProcessResponseDto> processKyc(
            @RequestParam("pan") MultipartFile panFile,
            @RequestParam("aadhaar") MultipartFile aadharFile,
            @RequestParam("bank") MultipartFile statementFile) {
        KycProcessResponseDto response = kycService.processKyc(panFile, aadharFile, statementFile);
        return ResponseEntity.ok(response);
    }

    // API 2 — Get KYC Result
    @GetMapping("/result/{caseId}")
    public ResponseEntity<KycResultResponseDto> getKycResult(@PathVariable String caseId) {
        KycResultResponseDto response = kycService.getKycResult(caseId);
        return ResponseEntity.ok(response);
    }
}