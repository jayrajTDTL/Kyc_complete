package com.company.kyc.service;

import com.company.kyc.dto.KycProcessResponseDto;
import com.company.kyc.dto.KycResultResponseDto;
import org.springframework.web.multipart.MultipartFile;

public interface KycService {

    KycProcessResponseDto processKyc(MultipartFile panFile, MultipartFile aadharFile,
            MultipartFile statementFile);

    KycResultResponseDto getKycResult(String caseId);
}