// package com.company.kyc.dto;

// import lombok.Data;

// @Data
// public class OcrCombinedResponseDto {
//     private PanData pan;
//     private AadhaarData aadhaar;
//     private StatementData statement;

//     @Data
//     public static class PanData {
//         private String pan_no;
//         private String name;
//         private String date_of_birth;
//         private String father_name;
//     }

//     @Data
//     public static class AadhaarData {
//         private String aadhaar_no;
//         private String name;
//         private String date_of_birth;
//     }

//     @Data
//     public static class StatementData {
//         private String account_no;
//         private String ifsc_code;
//         private String name;
//         private String address;
//     }
// }

package com.company.kyc.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;

@Data
public class OcrCombinedResponseDto {
    private PanData pan;
    private AadhaarData aadhaar;
    private StatementData statement;

    @Data
    public static class PanData {
        @JsonProperty("pan_no")
        private String pan_no;

        @JsonProperty("name")
        private String name;

        @JsonProperty("dob")
        private String date_of_birth;

        @JsonProperty("father_name")
        private String father_name;
    }

    @Data
    public static class AadhaarData {
        @JsonProperty("aadhaar_no")
        private String aadhaar_no;

        @JsonProperty("name")
        private String name;

        @JsonProperty("dob")
        private String date_of_birth;
    }

    @Data
    public static class StatementData {
        @JsonProperty("acc_no")
        private String account_no;

        @JsonProperty("ifsc_no")
        private String ifsc_code;

        @JsonProperty("name")
        private String name;

        @JsonProperty("address")
        private String address;
    }
}