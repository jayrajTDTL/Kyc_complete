package com.company.kyc.model;

import jakarta.persistence.*;
import lombok.Data;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "kyc_data")
@Data
public class KycData {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "case_id")
    private String caseId;

    private String name;

    @Column(name = "pan_number")
    private String panNumber;

    @Column(name = "fathers_name")
    private String fathersName;

    private LocalDate dob;

    @Column(name = "document_type")
    private String documentType; // "PAN", "AADHAAR", etc.

    @Column(name = "confidence_score")
    private Double confidenceScore; // 0.0 - 1.0

    @Column(name = "extraction_timestamp")
    private LocalDateTime extractionTimestamp;
}