package com.company.kyc.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class KycProcessResponseDto {

    private String caseId;
    private String status;

    private LocalDateTime processingStartTime;
    private String pipelinePhase;
    private Double expectedProcessingTimeSeconds;

    // Matching Results
    private Boolean nameMatch;
    private Boolean dobMatch;
    private Boolean accountMatch;

    // Risk & Decision
    private Integer riskScore;
    private String decision;

    // OCR Extracted Data
    private OcrCombinedResponseDto ocrData;

    public KycProcessResponseDto(String caseId, String status) {
        this.caseId = caseId;
        this.status = status;
    }
}