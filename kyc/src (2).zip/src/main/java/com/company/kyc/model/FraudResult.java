package com.company.kyc.model;

import jakarta.persistence.*;
import lombok.Data;

@Entity
@Table(name = "fraud_result")
@Data
public class FraudResult {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "case_id")
    private String caseId;

    @Column(name = "fraud_score")
    private Integer fraudScore;

    private String flags;
}